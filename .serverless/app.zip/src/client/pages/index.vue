<template>
	<div>
		<h1>Hello world!</h1>
		<app-button/>
	</div>
</template>